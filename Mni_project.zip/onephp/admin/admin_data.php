<?php
include 'C:/xampp/htdocs/php/miniproject/onephp/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

//Approve Vendor
if(isset($_POST['Approve'])){

    $id = $_POST["approve_id"];

    $data = "SELECT * FROM vendors_request WHERE id = '$id'";
    $res = mysqli_query($conn, $data);
     

    $fetch_data = mysqli_fetch_assoc($res); 
    $name = $fetch_data['name'];
    $s_name = $fetch_data['shop_name'];
    $mobile = $fetch_data['mobile_no'];
    $email = $fetch_data['email'];
    $address = $fetch_data['address'];
    $area = $fetch_data['area'];
    $photo_id = $fetch_data['photo_id'];
    $password = $fetch_data['password'];
    $status = "Active";

    $mail = new PHPMailer(true);

    try {
        //Server settings
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'devp45117211@gmail.com';                      //SMTP username
        $mail->Password   = 'omtgjqflyupfczsp';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('from@example.com', 'Way to Street Food');
        $mail->addAddress($email);     //Add a recipient
                

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Account activated';
        $mail->Body    = '<b>Your Way to Street Food account was activated!</b> <br><br> Hello! <br> Thanks for joining us! <br><br> If you have any questions, contact us at devp45117211@gmail.com';

        $mail->send();

        // store data in database
        $insert = "insert into vendors_id(name,shop_name,mobile_no,email,address,area,photo_id,password,status) values('$name','$s_name','$mobile','$email','$address','$area','$photo_id','$password','$status')";
        $iquery = mysqli_query($conn,$insert);

        if($iquery){
            $delete = "DELETE FROM `vendors_request` WHERE id = '$id'";
            $dquery = mysqli_query($conn,$delete);
            header('Location: admin.php');

        }else{
            header('Location: admin.php');
        }
    } catch (Exception $e) {
        ?>
            <script> 
                alert("Message could not be sent. Try again later");
            </script> 
        <?php
    }
}


//Reject Vendor
if(isset($_POST['Reject'])){

    $id = $_POST["Reject_id"];

    $data = "SELECT * FROM vendors_request WHERE id = '$id'";
    $res = mysqli_query($conn, $data);
    
    $fetch_data = mysqli_fetch_assoc($res); 
    $email = $fetch_data['email'];


    $mail = new PHPMailer(true);

    try {
        //Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'devp45117211@gmail.com';                      //SMTP username
        $mail->Password   = 'omtgjqflyupfczsp';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('from@example.com', 'Way to Street Food');
        $mail->addAddress($email);     //Add a recipient
                

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Account Rejected';
        $mail->Body    = 'Your request is Rejected by Admin <br><br> If you have any questions, contact us at devp45117211@gmail.com';

        $mail->send();

        //delete from database
        $delete = "DELETE FROM `vendors_request` WHERE id = '$id'";
        $dquery = mysqli_query($conn,$delete);
        
        if($iquery){
            
            header('Location: admin.php');
    
        }else{
            
            header('Location: admin.php');
        }
    } catch (Exception $e) {
        ?>
            <script> 
                alert("Message could not be sent. Try again later");
            </script> 
        <?php
    }
}



 

//active Vendor
if(isset($_POST['activate'])){

    $id = $_POST["v_active"]; 

    $delete = "UPDATE vendors_id SET status = 'Active' WHERE vendor_id = '$id'";
    $dquery = mysqli_query($conn,$delete);
    
    if($dquery){ 
        header('Location: vendor.php'); 

    }else{
        header('Location: vendor.php');
    }
}


//deactive Vendor
if(isset($_POST['deactivate'])){

    $id = $_POST["v_deactive"];

    $delete = "UPDATE vendors_id SET status = 'Inactive' WHERE vendor_id = '$id'";
    $dquery = mysqli_query($conn,$delete);
    
    if($dquery){ 
        header('Location: vendor.php');

    }else{
        header('Location: vendor.php');
    }
}

//Delete Vendor
if(isset($_POST['vendor_delete'])){

    $id = $_POST["v_delete"];

    $delete = "DELETE FROM `vendors_id` WHERE vendor_id = '$id'";
    $dquery = mysqli_query($conn,$delete);
    
    if($dquery){ 
        header('Location: vendor.php');

    }else{
        header('Location: vendor.php');
    }
}


//Delete User
if(isset($_POST['u_delete'])){

    $id = $_POST["user_id"];

    $delete = "DELETE FROM `users` WHERE user_id = '$id'";
    $dquery = mysqli_query($conn,$delete);
    
    if($dquery){ 
        header('Location: user.php');

    }else{
        header('Location: user.php');
    }
}

?>