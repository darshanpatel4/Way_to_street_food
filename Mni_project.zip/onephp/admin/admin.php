<?php
include 'C:/xampp/htdocs/php/miniproject/onephp/config.php';
session_start();


if (!isset($_SESSION['email'])) {
    header("Location: login.php");
}

// Total user count
$u_query = "select * from users";
$u_result = mysqli_query($conn, $u_query);
$usercount = mysqli_num_rows( $u_result );


// Total Vendors count
$v_request = "select * from vendors_request";
$request_result = mysqli_query($conn, $v_request);
$requestcount = mysqli_num_rows( $request_result );


// Total Vendors count
$v_query = "select * from vendors_id";
$v_result = mysqli_query($conn, $v_query);
$vendorscount = mysqli_num_rows( $v_result );

// Total order count
$o_query = "select * from order_details";
$o_result = mysqli_query($conn, $o_query);
$ordercount = mysqli_num_rows( $o_result );

$sql = "SELECT * FROM vendors_request";  
$result = mysqli_query($conn, $sql);  


?>




<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/Admin.css">
    <title>Admin panel</title>
</head>

<body>
        <div class="container">
            <div class="sidebar">
                <ul>
                    <li>
                        <a>
                            <div class="title">Admin Panal</div>
                        </a>
                    </li>
                    <li class="active">
                        <a href="admin.php">
                            <div class="title">Dashboard</div>
                        </a>
                    </li>
                    <li>
                        <a href="vendor.php">
                            <div class="title">Vendors</div>
                        </a>
                    </li>
                    <li>
                        <a href="user.php">
                            <div class="title">Users</div>
                        </a>
                    </li>
                    <li> 
                        <a href="item.php">
                            <div class="title">Items</div>
                        </a>
                    </li>
                    <li>
                        <a href="order_details.php">
                            <div class="title">Order</div>
                        </a>
                    </li>
                    <li>
                        <a href="payment_details.php">
                            <div class="title">Payment</div>
                        </a>
                    </li>
                    <li>
                        <a href="logout.php">
                            <div class="title">Logout</div>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="main">

                <div class="cards">
                    <div class="card">
                        <div class="card-content">
                            <div class="number"><?php echo $usercount ?></div>
                            <div class="card-name">User</div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <div class="number"><?php echo $requestcount ?></div>
                            <div class="card-name">Vendors Requests</div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <div class="number"><?php echo $vendorscount ?></div>
                            <div class="card-name">Vendors</div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-content">
                            <div class="number"><?php echo $ordercount ?></div>
                            <div class="card-name">Total Orders</div>
                        </div>
                    </div>
                </div>


                <div class="tables">
                    <div class="request">
                        <div class="heading">
                            <h2>Vendors Requests</h2>
                        </div>
                        <table class="appointments">
                            <thead>
                                <td>Name</td>
                                <td>Shop Name</td>
                                <td>Area</td>
                                <td>Actions</td>
                            </thead>
                            <?php
                                if(mysqli_num_rows($result) > 0)  
                                { 
                                    while($row = mysqli_fetch_array($result))  
                                    {
                            ?>
                                <tbody>
                                    <tr>
                                        <td><?php echo $row["name"];?></td>
                                        <td><?php echo $row["shop_name"];?></td>
                                        <td><?php echo $row["area"];?></td>
                                        <td>
                                            <form action="request_view.php" method="post">
                                                <!-- <a href="view_bills.php"><button type="submit" class="vbtn" name="view">View</button></a> -->
                                                <input type="hidden" name="view_id" value="<?php echo $row['id'] ?>">
                                                <button type="submit" class="vbtn" name="view">View</button>
                                        
                                            </form>
                                        </td>
                                    </tr>
                                </tbody>
                            <?php     
                                    }  
                                } 
                                else{
                                    ?>
                                        <td colspan="5"><h3><?php echo "No Request Panding"; ?></h3> </td>
                                    <?php
                                }  
                            ?>  
                        </table>
                    </div>
                </div>
            </div>
        </div>
<script>
function checkReject()
{
    return confirm('Are you sure want to Reject this Vendor?');
}

</script>
</body>
</html>