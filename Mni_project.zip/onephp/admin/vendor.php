<?php
include 'C:/xampp/htdocs/php/miniproject/onephp/config.php';
require_once "admin_data.php";
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
}

$sql = "SELECT * FROM vendors_id";  
$result = mysqli_query($conn, $sql);   

?>




<!DOCTYPE html>
<html lang="en">
 
<head>
    <link rel="stylesheet" href="style/Admin.css">
    <title>Admin panel</title>
</head>

<body>
    <div class="container">
        <div class="sidebar">
            <ul>
                <li>
                    <a>
                        <div class="title">Admin Panal</div>
                    </a>
                </li>
                <li>
                    <a href="admin.php">
                        <div class="title">Dashboard</div>
                    </a>
                </li>
                <li>
                    <a href="vendor.php">
                        <div class="title">Vendors</div>
                    </a>
                </li>
                <li>
                    <a href="user.php">
                        <div class="title">Users</div>
                    </a>
                </li>
                <li> 
                    <a href="item.php">
                        <div class="title">Items</div>
                    </a>
                </li>
                <li>
                    <a href="order_details.php">
                        <div class="title">Order</div>
                    </a>
                </li>
                <li>
                    <a href="payment_details.php">
                        <div class="title">Payment</div>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <div class="title">Logout</div>
                    </a>
                </li>
            </ul>
        </div>
        <div class="main">
            <div class="tables">
                <div class="request">
                    <div class="heading">
                        <h2>Vendors List</h2>
                    </div>
                    <table class="appointments">
                        <thead>
                            <td>Name</td>
                            <td>Shop Name</td>
                            <td>Area</td>
                            <td>Mobile No</td>
                            <td>Status</td>
                            <td>Actions</td>
                        </thead>
                        <?php
                            if(mysqli_num_rows($result) > 0)  
                            {  
                                while($row = mysqli_fetch_array($result))  
                                {  
                        ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $row["name"];?></td>
                                    <td><?php echo $row["shop_name"];?></td>
                                    <td><?php echo $row["area"];?></td>
                                    <td><?php echo $row["mobile_no"];?></td>
                                    <td><?php echo $row["status"];?></td>
                                    <td>
                                        <form action="admin_data.php" method="post">
                                            <input type="hidden" name="v_active" value="<?php echo $row['vendor_id'] ?>">
                                            <button type="submit" class="vbtn" name="activate">View</button>

                                            <input type="hidden" name="v_delete" value="<?php echo $row['vendor_id'] ?>">
                                            <button type="submit" class="dbtn" name="vendor_delete" onclick='return checkdelete()'>Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            </tbody>
                        <?php  
                               }  
                            }  
                        ?>  
                    </table>
                </div>
            </div>
        </div>
    </div>

<script>

function checkdelete()
{
    return confirm('Are you sure want to delete the Vendor?');
}
function checkdeactivate()
{
    return confirm('Are you sure want to deactivate the Vendor?');
}

</script>
</body>

</html>