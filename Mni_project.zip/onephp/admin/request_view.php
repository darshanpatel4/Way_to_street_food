<?php
include 'C:/xampp/htdocs/php/miniproject/onephp/config.php';
    
$id = $_POST["view_id"]; 

$sql = "SELECT * FROM vendors_request where id = '$id'";  
$result = mysqli_query($conn, $sql); 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


//Approve Vendor
if(isset($_POST['Approve'])){

    $id = $_POST["Approve_id"];

    $data = "SELECT * FROM vendors_request WHERE id = '$id'";
    $res = mysqli_query($conn, $data);
     

    $fetch_data = mysqli_fetch_assoc($res); 
    $name = $fetch_data['name'];
    $s_name = $fetch_data['shop_name'];
    $mobile = $fetch_data['mobile_no'];
    $email = $fetch_data['email'];
    $address = $fetch_data['address'];
    $area = $fetch_data['area'];
    $photo_id = $fetch_data['photo_id'];
    $password = $fetch_data['password'];
    $status = "Active";

    $mail = new PHPMailer(true);

    try {
        //Server settings
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'devp45117211@gmail.com';                      //SMTP username
        $mail->Password   = 'omtgjqflyupfczsp';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('from@example.com', 'Way to Street Food');
        $mail->addAddress($email);     //Add a recipient
                

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Account activated';
        $mail->Body    = '<b>Your Way to Street Food account was activated!</b> <br><br> Hello! <br> Thanks for joining us! <br><br> If you have any questions, contact us at devp45117211@gmail.com';

        $mail->send();

        // store data in database
        $insert = "insert into vendors_id(name,shop_name,mobile_no,email,address,area,photo_id,password,status) values('$name','$s_name','$mobile','$email','$address','$area','$photo_id','$password','$status')";
        $iquery = mysqli_query($conn,$insert);

        if($iquery){
            $delete = "DELETE FROM `vendors_request` WHERE id = '$id'";
            $dquery = mysqli_query($conn,$delete);
            header('Location: admin.php');

        }else{
            header('Location: admin.php');
        }
    } catch (Exception $e) {
        ?>
            <script> 
                alert("Message could not be sent. Try again later");
            </script> 
        <?php
    }
    
}


//Reject Vendor
if(isset($_POST['Reject'])){

    $id = $_POST["Reject_id"];

    $data = "SELECT * FROM vendors_request WHERE id = '$id'";
    $res = mysqli_query($conn, $data);
    
    $fetch_data = mysqli_fetch_assoc($res); 
    $email = $fetch_data['email'];


    $mail = new PHPMailer(true);

    try {
        //Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'devp45117211@gmail.com';                      //SMTP username
        $mail->Password   = 'omtgjqflyupfczsp';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('from@example.com', 'Way to Street Food');
        $mail->addAddress($email);     //Add a recipient
                

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Account Rejected';
        $mail->Body    = 'Your request is Rejected by Admin <br><br> If you have any questions, contact us at devp45117211@gmail.com';

        $mail->send();

        //delete from database
        $delete = "DELETE FROM `vendors_request` WHERE id = '$id'";
        $dquery = mysqli_query($conn,$delete);
        
        if($iquery){
            
            header('Location: admin.php');
    
        }else{
            
            header('Location: admin.php');
        }
    } catch (Exception $e) {
        ?>
            <script> 
                alert("Message could not be sent. Try again later");
            </script> 
        <?php
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view</title>
    <link rel="stylesheet" href="style/request1.css">
    <script src="https://kit.fontawesome.com/f30fac2c61.js" crossorigin="anonymous"></script>
    <link
        href="https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Catamaran:wght@200&family=Courgette&family=Edu+TAS+Beginner:wght@700&family=Lato:wght@300;900&family=Mukta:wght@700&family=Mulish:wght@300&family=Open+Sans&family=PT+Sans:ital,wght@1,700&family=Poppins:wght@300&family=Raleway:wght@100&family=Roboto+Condensed:wght@700&family=Roboto+Slab&family=Roboto:wght@300&family=Source+Sans+Pro:wght@300&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="sidebar">
                <ul>
                    <li>
                        <a>
                            <div class="title">Admin Panal</div>
                        </a>
                    </li>
                    <li class="active">
                        <a href="admin.php">
                            <div class="title">Dashboard</div>
                        </a>
                    </li>
                    <li>
                        <a href="vendor.php">
                            <div class="title">Vendors</div>
                        </a>
                    </li>
                    <li>
                        <a href="user.php">
                            <div class="title">Users</div>
                        </a>
                    </li>
                    <li> 
                        <a href="item.php">
                            <div class="title">Items</div>
                        </a>
                    </li>
                    <li>
                        <a href="order_details.php">
                            <div class="title">Order</div>
                        </a>
                    </li>
                    <li>
                        <a href="payment_details.php">
                            <div class="title">Payment</div>
                        </a>
                    </li>
                    <li>
                        <a href="logout.php">
                            <div class="title">Logout</div>
                        </a>
                    </li>
                </ul>
        </div>
    </div>

    <div class="card">
        <a href="admin.php" class="a">&#8678; back</a>
        <div class="d">
        <?php
                if(mysqli_num_rows($result) > 0)  
                {
                    
                    while($row = mysqli_fetch_array($result))  
                    {
            ?>

            <div class="left">
                <?php echo '<img src="vendor_id/'.$row["photo_id"].'">'; ?>
            </div>

            <div class="right">
                <table>
                    <tr>
                        <td>
                            <h1>Shop Name : </h1>
                        </td>
                        <td>
                            <h1><?php echo $row['shop_name'];?></h1>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>Vendor Name : </h4>
                        </td>
                        <td>
                            <h4> <?php echo $row['name'];?></h4>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <h4>Phone No : </h4>
                        </td>
                        <td>
                            <h4><?php echo $row['mobile_no'];?></h4>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>Email Id : </h4>
                        </td>
                        <td>
                            <h4><?php echo $row['email'];?></h4>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>Address : </p>
                        </td>
                        <td>
                            <p><?php echo $row['address'];?></p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>Area : </p>
                        </td>
                        <td>
                            <p><?php echo $row['area'];?></p>
                        </td>
                    </tr>
                    <tr>
                        <form action="" method="post">
                            <td>
                                <input type="hidden" name="Approve_id" value="<?php echo $row['id'] ?>">
                                <button type="submit" class="btn" name="Approve">Approve</button>
                            </td>
                            
                            <td>
                                <input type="hidden" name="Reject_id" value="<?php echo $row['id'] ?>">
                                <button type="submit" class="rbtn" name="Reject" onclick='return checkReject()'>Reject</button>
                            </td> 
                        </form>                
                    </tr>


                </table>
            </div>
        <?php     
                }  
            }  
        ?>
        </div>
    </div>
</body>

</html>