<?php
session_start();
require 'C:/xampp/htdocs/php/miniproject/onephp/config.php';

if($_SERVER['REQUEST_METHOD'] == "POST"){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $emailquery = "select * from admin where email='$email'";

    $query = mysqli_query($conn,$emailquery);
    $emailcount = mysqli_num_rows($query);

    if ($emailcount > 0) {
        //Password match or not
        $fetch = mysqli_fetch_assoc($query);
        $fetch_pass = $fetch['password'];
        if(password_verify($password,$fetch_pass))
        {
            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;
            header("location: admin.php");
        }
        else
        {
            ?>
                <script> 
                    alert("Incorrect email or password!");
                </script> 
            <?php
        }
        
    }
    else
    {
        //pass and retype pass match or not
        ?>
            <script> 
                alert("plz enter valid email or password");
            </script> 
        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login page</title>
    <link rel="stylesheet" href="style/login.css">
</head>

<body>
    <div class="main">

        <div class="content">
            <form action="" method="post">
                <div class="form">
                    <h2>Admin Login</h2>
                    <input type="email" name="email" placeholder="Enter Email">
                    <input type="password" name="password" placeholder="Enter Password">
                    <!-- <a href="reg.php">Forgot password?</a> -->
                    <button type="submit" class="btnn" name="login">Login</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>