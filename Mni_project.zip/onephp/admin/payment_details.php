<?php
include 'C:/xampp/htdocs/php/miniproject/onephp/config.php';
require_once "admin_data.php";
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
}

$sql = "SELECT * FROM order_details INNER JOIN users ON order_details.user_id = users.user_id INNER JOIN vendors_id ON order_details.vendor_id = vendors_id.vendor_id";
$result = mysqli_query($conn, $sql);   

?>




<!DOCTYPE html>
<html lang="en">
 
<head>
    <link rel="stylesheet" href="style/Admin.css">
    <title>Admin panel</title>
</head>

<body>
    <div class="container">
        <div class="sidebar">
            <ul>
                <li>
                    <a>
                        <div class="title">Admin Panal</div>
                    </a>
                </li>
                <li>
                    <a href="admin.php">
                        <div class="title">Dashboard</div>
                    </a>
                </li>
                <li>
                    <a href="vendor.php">
                        <div class="title">Vendors</div>
                    </a>
                </li>
                <li>
                    <a href="user.php">
                        <div class="title">Users</div>
                    </a>
                </li>
                <li> 
                    <a href="item.php">
                        <div class="title">Items</div>
                    </a>
                </li>
                <li> 
                    <a href="order_details.php">
                        <div class="title">Order</div>
                    </a>
                </li>
                <li>
                    <a href="payment_details.php">
                        <div class="title">Payment</div>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <div class="title">Logout</div>
                    </a>
                </li>
            </ul>
        </div>
        <div class="main">
            <div class="tables">
                <div class="request">
                    <div class="heading">
                        <h2>Payment Details</h2>
                    </div>
                    <table class="appointments">
                        <thead>
                            <td>User Name</td>
                            <td>Shop Name</td>
                            <td>Payment ID</td>
                            <td>Amount</td>
                            <td>Date & Time</td>
                        </thead>
                        <?php
                            if(mysqli_num_rows($result) > 0)  
                            {  
                                while($row = mysqli_fetch_array($result))  
                                {  
                        ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $row["name"];?></td>
                                    <td><?php echo $row["shop_name"];?></td>
                                    <td><?php echo $row["razorpay_payment_id"];?></td>
                                    <td><?php echo $row["price"];?></td>
                                    <td><?php echo $row["date_time"];?></td>
                                </tr>
                            </tbody>
                        <?php  
                               }  
                            }  
                        ?>  
                    </table>
                </div>
            </div>
        </div>
    </div>
<script>

function checkdelete()
{
    return confirm('Are you sure want to delete the User?');
}

</script>
</body>

</html>