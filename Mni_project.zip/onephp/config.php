<?php
/*
    Connect to data base
*/

$server = 'localhost';
$user = 'root';
$pass = '';
$db = 'try';

$conn = mysqli_connect($server,$user,$pass,$db);


if($conn == false){
    dir('can not connect');
}



$keyId = 'rzp_test_9TB3asShG3RvdV';
$keySecret = 'zrpWBMrytnHq5UMUeVikNgfn';
$displayCurrency = 'INR';

?>