<?php require_once "userdata.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login page</title>
    <link rel="stylesheet" href="style/login.css">
</head>

<body>

    <div class="main">
        <div class="navbar"> 
            <div class="icon">
                <h2 class="logo">Way to Street Food</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="vendor/vendor.html">Vendors</a></li>
                    <li><a href="signup.php">Sign up</a></li>
                </ul>
            </div>

        </div>

        <video autoplay loop muted plays-inline class="black-video">
            <source src="style/food1.mp4" type="video/mp4">
        </video>

        <div class="content">
            <h1>Tasty &<br><span>Budget-Friendly Food</span> </h1>
            <p class="par">Discover the best food & beverages near by you</p>
            <form action="" method="post">
                <div class="form">
                    <h2>Login Here</h2>
                    <input type="email" name="email" placeholder="Enter Email">
                    <input type="password" name="password" placeholder="Enter Password">
                    <!-- <a href="reg.php">Forgot password?</a> -->
                    <button type="submit" class="btnn" name="login">Login</button>

                    <p class="link">Don't have an account<br>
                        <a href="signup.php">Sign up </a> here
                    </p>

                    <p class="link">
                        For More information visit us on
                    </p>

                    <div class="icons">
                        <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-google"></ion-icon></a>
                    </div>

                </div>
            </form>
        </div>
    </div>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>