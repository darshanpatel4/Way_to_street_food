<?php
include 'config.php';

$name = $_POST['user'];
$search = $_POST['search'];

$sql1 = "SELECT * FROM profile_vendor INNER JOIN vendors_id ON profile_vendor.vendor_id = vendors_id.vendor_id where `address` like '%$search%'";
$run_Sql1 = mysqli_query($conn, $sql1);

if(mysqli_num_rows($run_Sql1)==0){
    $sql1 = "SELECT * FROM profile_vendor INNER JOIN vendors_id ON profile_vendor.vendor_id = vendors_id.vendor_id where `area` like '%$search%'";
    $run_Sql1 = mysqli_query($conn, $sql1);

    if(mysqli_num_rows($run_Sql1)==0){
        $sql1 = "SELECT * FROM profile_vendor INNER JOIN vendors_id ON profile_vendor.vendor_id = vendors_id.vendor_id where `shop_name` like '%$search%'";
        $run_Sql1 = mysqli_query($conn, $sql1);

        if(mysqli_num_rows($run_Sql1)==0){
            $sql2 = "SELECT * FROM item INNER JOIN vendors_id ON item.vendor_id = vendors_id.vendor_id where `Item_name` like '%$search%'";
            $run_Sql2 = mysqli_query($conn, $sql2);
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Project</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style/Home.css">

</head> 

<body>
    <!-- header section starts  -->

    <header> 
        <div class="logo">Way to Street Food</div>

        <div id="menu-bar" class="fas fa-bars"></div>
        <nav class="navbar">
            <a href="home_user.php#gallery">Gallery</a>
            <a href="cart.php">Cart</a>
            <a href="orderdetails.php">Order</a>
            <div class="dropdown">
            <a><i class="fas fa-user-alt"></i> <?php echo $name ?></a>
                <div class="dropdown-content">
                    <a href="#">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>

    </header>

    <!-- header section ends -->

    <!-- home section starts  -->

    <section class="home" id="home">
        <video autoplay loop muted plays-inline class="black-video">
            <source src="style/food1.mp4" type="video/mp4">
        </video>

        <div class="content">

            <h3>Tasty & Budget-Friendly Food</h3>
            <form action="search_user.php" method="post">
                <input type="text" name="search" class="txt" placeholder="search your fav food&drinks" autocomplete="on">
                <input type="hidden" name="user" value="<?php echo $name; ?>">
                <input type="submit" class="src" value="Search">
            </form>
        </div>

    </section>

    <!-- home section ends -->



    <!-- popular section starts  -->

    <section class="popular" id="popular">

        <h1 class="heading"> most popular foods </h1>

        <div class="box-container">
            <?php
                if(mysqli_num_rows($run_Sql1) > 0)  
                {
                    
                    while($row = mysqli_fetch_array($run_Sql1))  
                    {
            ?>
                        <div class="box">
                            <span class="price">Best Seller</span>
                            <?php echo '<img src="vendor/item_photos/'.$row["photo"].'">'; ?>
                            <h3><?php echo $row["shop_name"];?> </h3>
                            <p><?php echo $row["item_name"];?></p>
                            <form action="orderpage.php" method="post">
                                <input type="hidden" name="vendor_id" value="<?php echo $row['vendor_id']; ?>">
                                <button type="submit" class="btn">order now</button>
                            </form>
                        </div>
            <?php     
                    }  
                }elseif(mysqli_num_rows($run_Sql2) > 0)  
                {
                    
                    while($row = mysqli_fetch_array($run_Sql2))  
                    {
            ?>
                        <div class="box">
                            <span class="price">Best Seller</span>
                            <?php echo '<img src="vendor/item_photos/'.$row["item_photo"].'">'; ?>
                            <h3><?php echo $row["shop_name"];?> </h3>
                            <p><?php echo $row["Item_name"];?></p>
                            <form action="orderpage.php" method="post">
                                <input type="hidden" name="vendor_id" value="<?php echo $row['vendor_id']; ?>">
                                <button type="submit" class="btn">order now</button>
                            </form>
                        </div>
            <?php     
                    }   
                }else
                {
                    ?>
                        <h1 class="heading"> Not Found </h1>
                    <?php
                }  
            ?>

        </div>
        
        <!-- <button type="submit" class="box-container vbtn" name="Reject">View More</button> -->

    </section>

    <!-- popular section ends -->

    <!-- custom js file link  -->
    <script src="style/script.js"></script>
    
</body>
</html>