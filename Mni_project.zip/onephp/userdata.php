<?php
session_start();
include 'config.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


$email_count=0;
$pass_match=0;

//user click on Sign up
if(isset($_POST['signup'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $mobile = mysqli_real_escape_string($conn, $_POST['num']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $retype_pass = mysqli_real_escape_string($conn, $_POST['retype_password']);

    $emailquery = "select * from users where email='$email' ";
    $query = mysqli_query($conn,$emailquery);

    $emailcount = mysqli_num_rows($query);

    if ($emailcount > 0) {
        //Email is already exist
        $email_count=1;
    }
    else
    {
        //pass and retype pass match or not
        if($password == $retype_pass){
            $password = password_hash($password, PASSWORD_BCRYPT);

            $mail = new PHPMailer(true);

            try {
                //Server settings
                // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'devp45117211@gmail.com';                      //SMTP username
                $mail->Password   = 'omtgjqflyupfczsp';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                //Recipients
                $mail->setFrom('from@example.com', 'Way to Street Food');
                $mail->addAddress($email);     //Add a recipient
                


                $code = rand(999999, 111111);

                //Content
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Email Verification Code';
                $mail->Body    = '<b>Your verification code is '.$code.'</b>';
                //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                $mail->send();

                // store otp & email in database
                $insert = "insert into otp(name,mobile_no,email,password,otp) values('$name','$mobile','$email','$password','$code')";
                $iquery = mysqli_query($conn,$insert);

                header("location: otp_verification.php");
                
            } catch (Exception $e) {
                ?>
                    <script> 
                        alert("Message could not be sent. Try again later");
                    </script> 
                <?php
                // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }
        else {
            $pass_match=1;
        }
    }
}

//otp valid or not
if(isset($_POST['op'])){
    // $delete = ("DELETE FROM otp WHERE time < (NOW() - INTERVAL 1 MINUTE)");
    // $dquery = mysqli_query($conn,$delete);

    $otp_code = mysqli_real_escape_string($conn, $_POST['otp']);
    $check_code = "SELECT * FROM otp WHERE otp = $otp_code";
    $code_res = mysqli_query($conn, $check_code);
    
    if(mysqli_num_rows($code_res) > 0){
        $fetch_data = mysqli_fetch_assoc($code_res); 
        $name = $fetch_data['name'];
        $mobile = $fetch_data['mobile_no'];
        $email = $fetch_data['email'];
        $password = $fetch_data['password'];

        $insert = "insert into users(name,mobile_no,email,password) values('$name','$mobile','$email','$password')";
        $iquery = mysqli_query($conn,$insert);

        if($iquery){
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            header('location: home_user.php');
            exit();

        }else{
            ?>
                <script> 
                    alert("Failed while updating code!");
                </script> 
            <?php
            // $errors['otp-error'] = "Failed while updating code!";
        }
    }else{
        ?>
            <script> 
                alert("You've entered incorrect code!");
            </script> 
        <?php
        // $errors['otp-error'] = "You've entered incorrect code!";
    }
}


////user click on Login
if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
 
    $emailquery = "select * from users where email='$email'";

    $query = mysqli_query($conn,$emailquery);
    $emailcount = mysqli_num_rows($query);

    if ($emailcount > 0) {
        //Password match or not
        $fetch = mysqli_fetch_assoc($query); 
        $fetch_pass = $fetch['password'];
        if(password_verify($password,$fetch_pass))
        {
            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;
            header("location: home_user.php");
        }
        else
        {
            ?>
                <script> 
                    alert("Incorrect email or password!");
                </script> 
            <?php
            // echo "Incorrect email or password!";
            
        }
    }
    else
    {
        //pass and retype pass match or not
        ?>
            <script> 
                alert("It's look like you're not yet a member! Click on the bottom link to signup.");
            </script> 
        <?php
        // echo "It's look like you're not yet a member! Click on the bottom link to signup.";
    }
}


//vendors signup
if(isset($_POST['vsignup'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $shop_name = mysqli_real_escape_string($conn, $_POST['s_name']);
    $mobile = mysqli_real_escape_string($conn, $_POST['num']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $area = mysqli_real_escape_string($conn, $_POST['area']);

    $image = $_FILES['image']['name'];
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_folder = 'vendor_id/'.$image; 

    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $retype_pass = mysqli_real_escape_string($conn, $_POST['retype_password']);


    $emailquery = "select * from vendors_id where email='$email'";
    $query = mysqli_query($conn,$emailquery);

    $emailcount = mysqli_num_rows($query);

    if ($emailcount > 0) {
        //Email is already exist
        ?>
            <script> 
                alert("Email is already exist");
            </script> 
        <?php
    }
    else
    {
        //pass and retype pass match or not
        if($password == $retype_pass){ 

            if($image_size > 2000000){
                ?>
                    <script> 
                        alert("image size is too large!");
                    </script> 
                <?php
            }else{

                $password = password_hash($password, PASSWORD_BCRYPT);
                $insert = "insert into vendors_request(name,shop_name,mobile_no,email,address,area,photo_id,password) values('$name','$shop_name','$mobile','$email','$address','$area','$image','$password')";
                $iquery = mysqli_query($conn,$insert);
                if($iquery){
                    move_uploaded_file($image_tmp_name, $image_folder);
                    header('location:home.php');
                    
                }else{
                    ?>
                        <script> 
                            alert("registeration failed!");
                        </script> 
                    <?php
                }
            }
        }
        else {
            ?>
                <script> 
                    alert("Password is not match");
                </script> 
            <?php
        }
    }
}

//Vendors loogin 

if(isset($_POST['v_login'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
 
    $emailquery = "select * from vendors_id where email='$email'";

    $query = mysqli_query($conn,$emailquery);
    $emailcount = mysqli_num_rows($query);

    if ($emailcount > 0) {
        //Password match or not
        $fetch = mysqli_fetch_assoc($query); 
        $fetch_pass = $fetch['password'];
        if(password_verify($password,$fetch_pass))
        {
            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;
            header("location: vendor_home.php");
        }
        else
        {
            // Incorrect email or password!;
            ?>
                <script> 
                    alert("Incorrect email or password!");
                </script> 
            <?php  
        }
        
    }
    else
    {
        //Email not found in database
        ?>
            <script> 
                alert("It's look like you're not yet a member! Click on the bottom link to signup.");
            </script> 
        <?php
    }
}


//Delete Item from cart
if(isset($_POST['item_delete'])){

    $id = $_POST["item_id"]; 

    $delete = "DELETE FROM cart WHERE cart_id = '$id'";
    $dquery = mysqli_query($conn,$delete);
    
    if($dquery){ 
        header('Location: cart.php');

    }else{
        header('Location: cart.php');
    }
}
?>