<?php require_once "userdata.php"; ?>

<?php
$email = $_SESSION['email'];

$sql = "SELECT * FROM users WHERE email = '$email'";
$run_Sql = mysqli_query($conn, $sql);
$fetch_info = mysqli_fetch_assoc($run_Sql);
$name = ucwords($fetch_info['name']);
$id = $fetch_info['user_id'];

$sql3 = "SELECT * FROM order_details INNER JOIN vendors_id ON order_details.vendor_id = vendors_id.vendor_id where user_id = '$id'";
$run_Sql3 = mysqli_query($conn, $sql3);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="style/cart1.css">

    <title>Order Details</title>
</head>

<body>

    <!-- CONTENT -->
    <section id="content">
        <!-- header section starts  -->

        <header>
            <div class="logo">Way to Street Food</div>

            <div id="menu-bar" class="fas fa-bars"></div>
        <nav class="navbar">
            <a href="home_user.php">Home</a>
            <a href="cart.php">Cart</a>
            <a href="orderdetails.php">Order</a>
            <div class="dropdown">
            <a><i class="fas fa-user-alt"></i> <?php echo $name ?></a>
                <div class="dropdown-content">
                    <a href="#">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>

        </header>

        <!-- header section ends -->
        <!-- MAIN -->
        <main>
            <div class="home">
                <div class="content">

                    <div class="head-title">
                        <div class="left">
                            <h1>Order Details</h1>
                        </div>

                    </div>

                    <div class="table-data">
                        <div class="order">
                            <div class="head">
                                <h3>
                                    Items
                                </h3>
                            </div>

                            
                            <table>
                                <thead>
                                    <tr>
                                        <th>Shop Name</th>
                                        <th>Item Name</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>

                                <tbody>
                                <?php
                                    if(mysqli_num_rows($run_Sql3) > 0)  
                                    {
                    
                                        while($row = mysqli_fetch_array($run_Sql3))  
                                        {
                                    ?>
                                            <tr>
                                                <td>
                                                    <p>
                                                        <?php echo $row["shop_name"];?>
                                                    </p>
                                                </td>
                                                <td>
                                                    <?php echo $row["item_name"];?>
                                                </td>
                                                <td>
                                                    <?php echo $row["quantity"];?>
                                                </td>
                                                <td>
                                                    <?php echo $row["price"];?>
                                                </td>
                                                <td>
                                                    <?php echo $row["order_status"];?>
                                                </td>
                                            </tr>
                                            <?php     
                                        }  
                                    }  
                                ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script>

        function checkdelete() {
            return confirm('Are you sure want to delete this Item?');
        }

    </script>
    <script src="script.js"></script>
</body>

</html>