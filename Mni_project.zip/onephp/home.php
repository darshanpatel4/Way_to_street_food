<?php
include 'config.php';

$sql1 = "SELECT * FROM profile_vendor INNER JOIN vendors_id ON profile_vendor.vendor_id = vendors_id.vendor_id LIMIT 12";
// $sql = "SELECT * FROM vendors_id LIMIT 12";
$run_Sql1 = mysqli_query($conn, $sql1);

$image = "SELECT * FROM item ORDER BY RAND() LIMIT 12";
$i_run = mysqli_query($conn, $image);
?>

<!DOCTYPE html>
<html lang="en">

<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Project</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style/Home.css">

</head> 

<body>
    <!-- header section starts  -->

    <header> 
        <div class="logo">Way to Street Food</div>

        <div id="menu-bar" class="fas fa-bars"></div>
        <nav class="navbar">
            <!-- <a href="#speciality">speciality</a>
            <a href="#popular">popular</a> -->

            <a href="#">About Us</a>
            <a href="vendor/vendor.html">Vendors</a>
            <a href="login.php">Login</a>
            <a href="signup.php">Sign up</a>
        </nav>

    </header>

    <!-- header section ends -->

    <!-- home section starts  -->

    <section class="home" id="home">
        <video autoplay loop muted plays-inline class="black-video">
            <source src="style/food1.mp4" type="video/mp4">
        </video>

        <div class="content">

            <h3>Tasty & Budget-Friendly Food</h3>
            <form action="search.php" method="post">
                <input type="text" name="search" class="txt" placeholder="search your fav food&drinks">
                <input type="submit" class="src" value="Search">
            </form>
        </div>

    </section>

    <!-- home section ends -->



    <!-- popular section starts  -->

    <section class="popular" id="popular">

        <h1 class="heading"> most popular foods </h1>

        <div class="box-container">
            <?php
                if(mysqli_num_rows($run_Sql1) > 0)  
                {
                    
                    while($row = mysqli_fetch_array($run_Sql1))  
                    {
            ?>
                        <div class="box">
                            <span class="price">Best Seller</span>
                            <?php echo '<img src="vendor/item_photos/'.$row["photo"].'">'; ?>
                            <h3><?php echo $row["shop_name"];?> </h3>
                            <p><?php echo $row["item_name"];?></p>
                            <button type="submit" class="btn" onclick="window.open('http://localhost/php/miniproject/onephp/login.php')">order now</button>
                        </div>
            <?php     
                    }  
                }  
            ?>
        </div>
        
        <!-- <button type="submit" class="box-container vbtn" name="Reject">View More</button> -->

    </section>

    <!-- popular section ends -->


    <!-- gallery section starts  -->

    <section class="gallery" id="gallery">

        <h1 class="heading">food gallery </h1>

        <div class="box-container">
            
            <?php
                if(mysqli_num_rows($i_run) > 0)  
                {
                    
                    while($row = mysqli_fetch_array($i_run))  
                    {
            ?>
                        <div class="box">
                            
                            <?php echo '<img src="vendor/item_photos/'.$row["item_photo"].'">'; ?>
                            <div class="content">
                                <h3><?php echo $row["Item_name"];?></h3>
                                <button type="submit" class="btn" onclick="window.open('http://localhost/php/miniproject/onephp/login.php')">order now</button>
                            </div>
                        </div>
            <?php     
                    }  
                }  
            ?>
        </div>
    </section>

    <!-- gallery section ends -->

    <!-- steps section starts  -->

    <div class="step-container">

        <h1 class="heading">how it works</h1>

        <section class="steps">

            <div class="box">
                <img src="images/step-1.jpg" alt="">
                <h3>choose your favorite food</h3>
            </div>
            <div class="box">
                <img src="images/step-2.jpg" alt="">
                <h3>Self Pickup your food</h3>
            </div>
            <div class="box">
                <img src="images/step-3.jpg" alt="">
                <h3>easy payments methods</h3>
            </div>
            <div class="box">
                <img src="images/step-4.jpg" alt="">
                <h3>and finally, enjoy your food</h3>
            </div>

        </section>

    </div>

    <!-- steps section ends -->



    <!-- custom js file link  -->
    <script src="style/script.js"></script>
    
</body>
</html>