<?php require_once "userdata.php"; ?>

<?php
$email = $_SESSION['email'];

$sql = "SELECT * FROM users WHERE email = '$email'";
$run_Sql = mysqli_query($conn, $sql);
$fetch_info = mysqli_fetch_assoc($run_Sql);
$name = ucwords($fetch_info['name']);
$id = $fetch_info['user_id'];
$mobile_no = $fetch_info['mobile_no'];

$sql1 = "SELECT * FROM cart INNER JOIN vendors_id ON cart.v_id = vendors_id.vendor_id where user_id = '$id'";
$run_Sql1 = mysqli_query($conn, $sql1);


$sql2 = "SELECT * FROM cart INNER JOIN vendors_id ON cart.v_id = vendors_id.vendor_id where user_id = '$id'";
$run_Sql2 = mysqli_query($conn, $sql2);

$total_price = 0;
if(mysqli_num_rows($run_Sql2) > 0)  
{                                        
    while($rows = mysqli_fetch_array($run_Sql2))  
    {
        $total_price = $total_price + $rows["item_price"];
    }
}else{
    $total_price = 1;
}

$sql3 = "SELECT * FROM order_details INNER JOIN vendors_id ON order_details.vendor_id = vendors_id.vendor_id where user_id = '$id'";
$run_Sql3 = mysqli_query($conn, $sql3);

?>


<?php

require('config.php');
require('razorpay-php/Razorpay.php');

// Create the Razorpay Order

use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);

//
// We create an razorpay order using orders api
// Docs: https://docs.razorpay.com/docs/orders
//

$price = $total_price;
$_SESSION['price'] = $price;
$customername = $name;
$_SESSION['email'] = $email;
$orderData = [
    'receipt'         => 3456,
    'amount'          => $price * 100, // 2000 rupees in paise
    'currency'        => 'INR',
    'payment_capture' => 1 // auto capture
];

$razorpayOrder = $api->order->create($orderData);

$razorpayOrderId = $razorpayOrder['id'];

$_SESSION['razorpay_order_id'] = $razorpayOrderId;

$displayAmount = $amount = $orderData['amount'];

if ($displayCurrency !== 'INR')
{
    $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
    $exchange = json_decode(file_get_contents($url), true);

    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
}

$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => "Way to Street Food",
    "description"       => "Enjoy food",
    "image"             => "https://th.bing.com/th/id/R.b44a47aeb7d1e163ea963550fff10df9?rik=YkT2hYybNS5uXA&riu=http%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2fthumb%2f2%2f23%2fEmblem-person-orange.svg%2f1024px-Emblem-person-orange.svg.png&ehk=NDNBYV%2bcdOnNeyLAlYa1CJOENy4NVqCTg3Ba70iiiD8%3d&risl=&pid=ImgRaw&r=0",
    "prefill"           => [
    "name"              => $customername,
    "email"             => $email,
    "contact"           => $mobile_no,
    ],
    "notes"             => [
    "address"           => "Hello World",
    "merchant_order_id" => "12312321",
    ],
    "theme"             => [
    "color"             => "#F37254"
    ],
    "order_id"          => $razorpayOrderId,
];

if ($displayCurrency !== 'INR')
{
    $data['display_currency']  = $displayCurrency;
    $data['display_amount']    = $displayAmount;
}

$json = json_encode($data);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="style/cart1.css">

    <title>Cart</title>
</head>

<body>

    <!-- CONTENT -->
    <section id="content">
        <!-- header section starts  -->

        <header>
            <div class="logo">Way to Street Food</div>

            <div id="menu-bar" class="fas fa-bars"></div>
        <nav class="navbar">
            <a href="home_user.php">Home</a>
            <a href="home_user.php#gallery">Gallery</a>
            <a href="orderdetails.php">Order</a>
            <div class="dropdown">
            <a><i class="fas fa-user-alt"></i> <?php echo $name ?></a>
                <div class="dropdown-content">
                    <a href="#">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>

        </header>

        <!-- header section ends -->
        <!-- MAIN -->
        <main>
            <div class="home">
                <div class="content">

                    <div class="head-title">
                        <div class="left">
                            <h1>Cart</h1>
                        </div>

                    </div>

                    <div class="table-data">
                        <div class="order">
                            <div class="head">
                                <h3>
                                    Items
                                </h3>
                                <div class="abtn">
                                <form action="verify.php" method="POST">
                                    <script
                                        src="https://checkout.razorpay.com/v1/checkout.js"
                                        data-key="<?php echo $data['key']?>"
                                        data-amount="<?php echo $data['amount']?>"
                                        data-currency="INR"
                                        data-name="<?php echo $data['name']?>"
                                        data-image="<?php echo $data['image']?>"
                                        data-description="<?php echo $data['description']?>"
                                        data-prefill.name="<?php echo $data['prefill']['name']?>"
                                        data-prefill.email="<?php echo $data['prefill']['email']?>"
                                        data-prefill.contact="<?php echo $data['prefill']['contact']?>"
                                        data-notes.shopping_order_id="3456"
                                        data-order_id="<?php echo $data['order_id']?>"
                                        <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']; ?>" <?php } ?>
                                        <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
                                    >
                                    </script>
                                    <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
                                    <input type="hidden" name="shopping_order_id" value="3456">
                                </form>
                                </div>
                            </div>

                            
                            <table>
                                <thead>
                                    <tr>
                                        <th>Shop Name</th>
                                        <th>Item Name</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                <?php
                                    if(mysqli_num_rows($run_Sql1) > 0)  
                                    {
                    
                                        while($row = mysqli_fetch_array($run_Sql1))  
                                        {
                                    ?>
                                            <tr>
                                                <td>
                                                    <p>
                                                        <?php echo $row["shop_name"];?>
                                                    </p>
                                                </td>
                                                <td>
                                                    <?php echo $row["item_name"];?>
                                                </td>
                                                <td>
                                                    <?php echo $row["quantity"];?>
                                                </td>
                                                <td>
                                                    <?php echo $row["item_price"];?>
                                                </td>
                                                <td>
                                                    <form action="" method="post">
                                                        <input type="hidden" name="item_id" value="<?php echo $row['cart_id']; ?>">
                                                        <button type="submit" class="dbtn" name="item_delete" onclick='return checkdelete()'>Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php     
                                        }  
                                    }  
                                ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script>

        function checkdelete() {
            return confirm('Are you sure want to delete this Item?');
        }

    </script>
    <script src="script.js"></script>
</body>

</html>