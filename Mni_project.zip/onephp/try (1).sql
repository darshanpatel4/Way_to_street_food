-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2023 at 07:40 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `try`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'darshanp1502@gmail.com', '$2y$10$AGKaf70F/e4XlnGbl3d79uhROrM8BpmUKgMHy4Ay6mvfskKFKFf9e');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `v_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `item_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `v_id`, `item_name`, `quantity`, `item_price`) VALUES
(17, 5, 4, 'Chole kulche', 2, 120);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`) VALUES
(1, 'Breakfast'),
(2, 'Lunch'),
(3, 'Dinner'),
(4, 'Brunch');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `Item_name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `item_photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`item_id`, `vendor_id`, `category_id`, `Item_name`, `price`, `item_photo`) VALUES
(16, 4, 1, 'Jalebi', 700, 'jalebi.jpg'),
(20, 5, 1, 'Dhokla', 40, 'dhokla.jpeg'),
(21, 4, 4, 'Chole kulche', 60, 'chole kulche.jpg'),
(22, 5, 4, 'Misal pav', 50, 'mishal.jpeg'),
(23, 5, 1, 'Dabeli ', 20, 'Website image .JPG'),
(25, 5, 1, 'Samosa', 20, 'OIP.jpeg'),
(26, 5, 4, 'Bhjiya', 130, 'bhajiya.jpg'),
(27, 17, 2, 'Chole Bhature', 60, 'Chole Bhature.jpg'),
(28, 4, 4, 'Dosa', 120, 'dosa.jpg'),
(29, 4, 4, 'Pizza', 100, 'pizza.jpeg'),
(30, 4, 1, 'Poha', 25, 'Poha.jpg'),
(31, 4, 1, 'dokla', 20, 'dhokla.jpeg'),
(32, 4, 1, 'fafda', 50, 'Fafda.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `razorpay_payment_id` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `order_status` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `razorpay_payment_id`, `user_id`, `vendor_id`, `item_name`, `quantity`, `price`, `payment_status`, `order_status`, `date_time`) VALUES
(1, 'order_LLAL5gKWiuLBG5', 'pay_LLALMvCE2TqixW', 5, 4, 'Dosa', 1, 120, 'success', 'completed', '2023-02-26 23:36:32'),
(2, 'order_LLAL5gKWiuLBG5', 'pay_LLALMvCE2TqixW', 5, 4, 'Pizza', 1, 100, 'success', 'completed', '2023-02-26 23:36:32'),
(3, 'order_LLB7LoSTrjTtwO', 'pay_LLB7cYW6ylZr4G', 6, 4, 'Chole kulche', 2, 120, 'success', 'pending', '2023-02-27 00:22:13'),
(4, 'order_LLL0gTXTm3R8vM', 'pay_LLL14edZsBBtOU', 6, 5, 'Samosa', 6, 120, 'success', 'completed', '2023-02-27 10:02:59'),
(5, 'order_LLooFfyunpYKja', 'pay_LLoocogr3TODSm', 5, 5, 'Dabeli ', 5, 100, 'success', 'pending', '2023-02-28 15:12:00'),
(6, 'order_LLooFfyunpYKja', 'pay_LLoocogr3TODSm', 5, 5, 'Misal pav', 1, 50, 'success', 'pending', '2023-02-28 15:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otp` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`id`, `name`, `mobile_no`, `email`, `password`, `otp`, `time`) VALUES
(1, 'Darshan', '9426404511', 'darshanpateldk@gmail.com', '$2y$10$RLqTbdEsqvvGH/jn9EFble6EMKA1BM5UZqUNDwNcIL0x4AVoIUrom', 705146, '2023-02-25 19:39:43'),
(2, 'DARSHAN K PATEL', '8866004511', 'darshanpatedk@gmail.com', '$2y$10$/TVR0skR9JpQd1L9l80ggeZUcKeXAurNmdLwKOMWjS2KZ/FXGsvVu', 137588, '2023-02-27 00:18:30');

-- --------------------------------------------------------

--
-- Table structure for table `profile_vendor`
--

CREATE TABLE `profile_vendor` (
  `profile_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profile_vendor`
--

INSERT INTO `profile_vendor` (`profile_id`, `vendor_id`, `photo`, `item_name`) VALUES
(1, 4, 'Fafda.jpg', 'fafda'),
(2, 5, 'OIP.jpeg', 'Samosa'),
(3, 17, 'Chole Bhature.jpg', 'Chole Bhature');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `mobile_no`, `email`, `password`, `created_at`) VALUES
(5, 'Darshan Patel', '8866004511', 'darshanpatel123dk@gmail.com', '$2y$10$G6SId8OSN1Pq3pFDrSfeTe4LZWr9ZOJVlxsMNJ21icO6gMw6jqIay', '2023-02-04 20:40:25'),
(6, 'Darshan', '9426404511', 'darshanpateldk@gmail.com', '$2y$10$RLqTbdEsqvvGH/jn9EFble6EMKA1BM5UZqUNDwNcIL0x4AVoIUrom', '2023-02-25 19:39:56');

-- --------------------------------------------------------

--
-- Table structure for table `vendors_id`
--

CREATE TABLE `vendors_id` (
  `vendor_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `shop_name` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `area` varchar(100) NOT NULL,
  `photo_id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(15) NOT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendors_id`
--

INSERT INTO `vendors_id` (`vendor_id`, `name`, `shop_name`, `mobile_no`, `email`, `address`, `area`, `photo_id`, `password`, `status`, `requested_at`) VALUES
(4, 'Vandish', 'Hetvi poha', '9879245045', 'vandish@gmail.com', 'Near Gls', 'Low garden', 'Screenshot_20221115_005145.png', '$2y$10$93Bf41Nr3Rqrx20OBa2mT.vW4Qm/KNMSfIV8T1yWN/SCOuNM3xlWi', 'Active', '2023-02-02 22:12:48'),
(5, 'Dev patel', 'dk', '9426404511', 'darshanp1502@gmail.com', 'LJ clg', 'amraiwadi', 'Screenshot_20221211_111436.png', '$2y$10$.6WarbEOPZg1cnC6rqhapu75INwFNWANWFL1rGTQhzzBLmAcqi0dG', 'Active', '2023-02-03 22:29:34'),
(11, 'Vandish', 'Poha House', '9879245045', 'darshanpatel123dk@gmail.com', 'gls uni. gate no 8', 'manek chok', 'Screenshot_20221115_005145.png', '$2y$10$qN3AuPYi6ZuU4.AzZO6D5OwEt88TMjEsLXnEFLYvppsYAu5uKN.rC', 'Active', '2023-02-03 23:02:21'),
(16, 'Darshan', 'RRR', '6959894758', 'dar@gmail.com', 'ajay', 'Rabari colony', 'R.jpeg', '$2y$10$Mvx/nRs1LKp8uKccBq7UWODBNt4qtZFmJGXJgWfmZTvR0T.F7dgte', 'Active', '2023-02-09 22:30:56'),
(17, 'viraj', 'Mahakal Pani-puri', '9687060801', 'virajchokshi60@gmail.com', 'gls suchi ka gar', 'adhjan madal', 'OIP.jpeg', '$2y$10$J8passmvNlZZnsTsHShx9OiDwo7QHWxDJTETWDdIAA0nKMw8cu.xO', 'Active', '2023-02-09 22:32:10');

-- --------------------------------------------------------

--
-- Table structure for table `vendors_request`
--

CREATE TABLE `vendors_request` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `shop_name` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `area` varchar(100) NOT NULL,
  `photo_id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendors_request`
--

INSERT INTO `vendors_request` (`id`, `name`, `shop_name`, `mobile_no`, `email`, `address`, `area`, `photo_id`, `password`, `requested_at`) VALUES
(7, 'Nishita', 'Jay Bhole', '9499812828', 'nishitabavaghela0708@gmail.com', 'new C.G Road', 'Chandkheda', 'Screenshot (100).png', '$2y$10$7FTLvRPrX83y/kNHweAjlOi1csVtiYpfK9a8HaPdFs6Rz/A3M2Od6', '2023-02-09 22:45:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `v_id` (`v_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `vendor_id` (`vendor_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_id` (`user_id`),
  ADD KEY `vendors_id` (`vendor_id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_vendor`
--
ALTER TABLE `profile_vendor`
  ADD PRIMARY KEY (`profile_id`),
  ADD KEY `id` (`vendor_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `vendors_id`
--
ALTER TABLE `vendors_id`
  ADD PRIMARY KEY (`vendor_id`);

--
-- Indexes for table `vendors_request`
--
ALTER TABLE `vendors_request`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `otp`
--
ALTER TABLE `otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `profile_vendor`
--
ALTER TABLE `profile_vendor`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vendors_id`
--
ALTER TABLE `vendors_id`
  MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `vendors_request`
--
ALTER TABLE `vendors_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `v_id` FOREIGN KEY (`v_id`) REFERENCES `vendors_id` (`vendor_id`);

--
-- Constraints for table `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `category_id` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `vendor_id` FOREIGN KEY (`vendor_id`) REFERENCES `vendors_id` (`vendor_id`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `u_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `vendors_id` FOREIGN KEY (`vendor_id`) REFERENCES `vendors_id` (`vendor_id`);

--
-- Constraints for table `profile_vendor`
--
ALTER TABLE `profile_vendor`
  ADD CONSTRAINT `id` FOREIGN KEY (`vendor_id`) REFERENCES `vendors_id` (`vendor_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
