<?php

require('config.php');
session_start();
//db connection

require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    $razorpay_order_id = $_SESSION['razorpay_order_id'];
    $razorpay_payment_id = $_POST['razorpay_payment_id'];

    $email = $_SESSION['email'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $run_Sql = mysqli_query($conn, $sql);
    $fetch_info = mysqli_fetch_assoc($run_Sql);
    $u_id = $fetch_info['user_id'];

    $sql = "SELECT * FROM cart WHERE user_id = '$u_id'";
    $run_Sql = mysqli_query($conn, $sql);
    // $fetch_info = mysqli_fetch_assoc($run_Sql);
    // $v_id = $fetch_info['v_id'];

    if(mysqli_num_rows($run_Sql) > 0)  
    {

        while($row = mysqli_fetch_array($run_Sql))  
        {
            $item_name= $row["item_name"];
            $quantity = $row["quantity"];
            $v_id = $row['v_id'];
            $price = $row['item_price'];

            $sql = "INSERT INTO `order_details` (`order_id`, `razorpay_payment_id`,`user_id`,`vendor_id`,`item_name`,`quantity`, `payment_status`,`order_status`, `price`) VALUES ('$razorpay_order_id', '$razorpay_payment_id','$u_id','$v_id','$item_name','$quantity', 'success','pending', '$price')";
            if(mysqli_query($conn, $sql)){
                $delete = "DELETE FROM cart WHERE user_id = '$u_id'";
                $dquery = mysqli_query($conn,$delete);
                header('Location: orderdetails.php');
            }
        }
    }
}