<?php require_once "userdata.php"; ?>
<?php
include 'config.php';
error_reporting(0);
$vendor_id = $_POST["vendor_id"];
$_SESSION['vendor_id'] = $vendor_id;
$vendor_id1 = $_SESSION['vendor_id'];

if($vendor_id1 != 0){
    $item = "SELECT * FROM item INNER JOIN category ON item.category_id = category.id where vendor_id = '$vendor_id1'";
    $Sql1 = mysqli_query($conn, $item);
}else{
    $vendor_id1 = $_POST['v_id'];
    $item = "SELECT * FROM item INNER JOIN category ON item.category_id = category.id where vendor_id = '$vendor_id1'";
    $Sql1 = mysqli_query($conn, $item);
}


$sql = "SELECT * FROM vendors_id WHERE vendor_id = '$vendor_id1'";
$run_Sql = mysqli_query($conn, $sql);
$fetch_info = mysqli_fetch_assoc($run_Sql);
$shop_name = ucwords($fetch_info['shop_name']);


$email = ucwords($_SESSION['email']);
$u_sql = "SELECT * FROM users WHERE email = '$email'";
$u_run = mysqli_query($conn, $u_sql);
$fetch = mysqli_fetch_assoc($u_run);
$name = ucwords($fetch['name']);
$user_id = $fetch['user_id'];


if(isset($_POST['add'])){
    $v_id = $_POST['v_id'];
    $i_name = $_POST['i_name'];
    $que = $_POST['que'];
    $price = $_POST['p'];

    if($que != 0){
        $total = $price * $que;
        $insert = "insert into cart(item_name,user_id,v_id,quantity,item_price) values('$i_name','$user_id','$v_id','$que','$total')";
        $iquery = mysqli_query($conn,$insert);
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Project</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style/order1.css">

</head>

<body>
    <!-- header section starts  -->

    <header>
        <div class="logo">Way to Street Food</div>

        <div id="menu-bar" class="fas fa-bars"></div>
        <nav class="navbar">
            <a href="home_user.php#popular">Home</a>
            <a href="orderdetails.php">Order</a>
            <a href="cart.php">Cart</a>
            <div class="dropdown">
            <a><i class="fas fa-user-alt"></i> <?php echo $name ?></a>
                <div class="dropdown-content">
                    <a href="#">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>

    </header>

    <!-- header section ends -->

    <div class="menu">
        <div class="heading">
            <h1><?php echo $shop_name; ?></h1>
            <h3>&mdash; MENU &mdash; </h3>
        </div>

        <?php
            if(mysqli_num_rows($Sql1) > 0)  
            {
                    
                while($row = mysqli_fetch_array($Sql1))  
                {
        ?>
                
                    <div class="food-items">
                        <?php echo '<img src="vendor/item_photos/'.$row["item_photo"].'">'; ?>
                        
                        <div class="details">
                            <div class="details-sub">
                                <h5><?php echo $row['Item_name']; ?></h5>
                            
                                <div class="price">
                                    <span id="price"><?php echo $row['price']; ?></span>
                                    
                                </div>
                            </div>
                            
                            <p><?php echo $row['category_name']; ?></p>
                     
                            <div class="product-qty">
                                <form action="" method="post">
                                    <p> Select Quantity: <input type="number" value="0" name="que"> </p> <br>
                                    <input type="hidden" name="p" value="<?php echo $row['price']; ?>">
                                    <input type="hidden" name="i_name" value="<?php echo $row['Item_name'];?>">
                                    <input type="hidden" name="v_id" value="<?php echo $row['vendor_id']; ?>">
                                    <button type="submit" name="add" class="vbtn">Add</button>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                
        <?php     
                }  
            }  
        ?>
            </div>
            
    <script src="style/script.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>
</html>