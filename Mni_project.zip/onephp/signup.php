<?php require_once "userdata.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Signup page</title>
    <link rel="stylesheet" href="style/u_signup.css">
</head>

<body>
    <script> 
        <?php
            if($email_count){
                ?> 
                    alert("Email is already exist");
                <?php
            }

            if($pass_match){
                ?>
                    alert("Password is not match");
                <?php
            }
        ?>
    </script>
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Way to Street Food</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="vendor/vendor.html">Vendors</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </div>

        </div>

        <video autoplay loop muted plays-inline class="black-video">
            <source src="style/food1.mp4" type="video/mp4">
        </video>

        <div class="content">
            <h1>Tasty &<br><span>Budget-Friendly Food</span> </h1>
            <p class="par">Discover the best food & beverages near by you</p>

            <form action="" method="post">
                <div class="form">
                    <h2>Sign Up Here</h2>
                    <input type="text" name="name" placeholder="Enter Name" pattern="{A-Za-z}" title="Number is not allowed" required>
                    <input type="tel" name="num" placeholder="Enter Mobile No." pattern="[0-9]{10}" title="Enter valid Number" required>
                    <input type="email" name="email" placeholder="Enter Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter valid Email" required>
                    <input type="password" name="password" placeholder="Enter Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                    <input type="password" name="retype_password" placeholder="Retype password" required>
                    <button type="submit" class="btnn" name="signup">Sign Up</button>
                    

                    <p class="link">have an account ?
                        <a href="login.php">Login</a>
                    </p>

                    <p class="link">
                        For More information visit us on
                    </p>

                    <div class="icons">
                        <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-google"></ion-icon></a>
                    </div>

                </div>
            </form>
        </div>
    </div>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>