<?php require_once "userdata.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Verification</title>
    <link rel="stylesheet" href="style/otp.css">
</head>

<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">WAY TO STREET FOOD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="#">ABOUT</a></li>
                    <li><a href="#">CONTACT</a></li>
                    <li><a href="#">STREET VENDOR</a></li>
                </ul>
            </div>
 
        </div>

        <video autoplay loop muted plays-inline class="black-video">
            <source src="style/food1.mp4" type="video/mp4">
        </video>

        <div class="content">
            <h1>Tasty &<br><span>Budget-Friendly Food</span> </h1>
            <p class="par">Discover the best food & beverages near by you</p>
            <form action="" method="post">
                <div class="form">
                    <h2>OTP Verification</h2>
                    <input type="number" name="otp" placeholder="Enter OTP">
                    <button type="submit" class="btnn" name="op">Submit</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>